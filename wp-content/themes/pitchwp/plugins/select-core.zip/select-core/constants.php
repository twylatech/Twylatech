<?php

define( 'PITCH_CORE_VERSION', '1.3.1' );
define( 'PITCH_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'PITCH_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'PITCH_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'PITCH_CORE_CPT_PATH', PITCH_CORE_ABS_PATH . '/modules/post-types' );
define( 'PITCH_CORE_MODULES_PATH', PITCH_CORE_ABS_PATH . '/modules' );
define( 'PITCH_CORE_MODULES_URL_PATH', PITCH_CORE_URL_PATH . 'modules' );